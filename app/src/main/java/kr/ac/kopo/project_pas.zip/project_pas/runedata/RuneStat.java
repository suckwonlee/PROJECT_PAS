package kr.ac.kopo.project_pas.runedata;

public class RuneStat {
    // TODO: 구현 예정
}
