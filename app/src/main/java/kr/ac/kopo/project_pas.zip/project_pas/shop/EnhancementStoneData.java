package kr.ac.kopo.project_pas.shop;

public class EnhancementStoneData {
    // TODO: 구현 예정
}
