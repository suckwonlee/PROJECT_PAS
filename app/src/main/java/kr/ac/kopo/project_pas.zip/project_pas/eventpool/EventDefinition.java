package kr.ac.kopo.project_pas.eventpool;

public class EventDefinition {
    // TODO: 구현 예정
}
