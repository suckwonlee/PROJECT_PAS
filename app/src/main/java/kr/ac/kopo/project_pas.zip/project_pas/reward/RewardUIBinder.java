package kr.ac.kopo.project_pas.reward;

public class RewardUIBinder {
    // TODO: 구현 예정
}
