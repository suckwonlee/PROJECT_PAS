package kr.ac.kopo.project_pas.debug;

public class DevConsole {
    // TODO: 구현 예정
}
