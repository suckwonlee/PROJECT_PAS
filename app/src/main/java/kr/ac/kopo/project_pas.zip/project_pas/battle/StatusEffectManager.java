package kr.ac.kopo.project_pas.battle;

public class StatusEffectManager {
    // TODO: 구현 예정
}
