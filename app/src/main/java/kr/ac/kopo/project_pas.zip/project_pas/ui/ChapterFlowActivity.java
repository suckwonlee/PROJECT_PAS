package kr.ac.kopo.project_pas.ui;

public class ChapterFlowActivity {
    // TODO: 구현 예정
}
