package kr.ac.kopo.project_pas.characterdata.bardData;

public class BardPassiveSet {
    // TODO: {class_name} 구현 예정
}
