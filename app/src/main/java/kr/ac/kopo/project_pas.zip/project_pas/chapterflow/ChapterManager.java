package kr.ac.kopo.project_pas.chapterflow;

public class ChapterManager {
    // TODO: 구현 예정
}
