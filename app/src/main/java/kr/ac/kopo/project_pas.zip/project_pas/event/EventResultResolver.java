package kr.ac.kopo.project_pas.event;

public class EventResultResolver {
    // TODO: 구현 예정
}
