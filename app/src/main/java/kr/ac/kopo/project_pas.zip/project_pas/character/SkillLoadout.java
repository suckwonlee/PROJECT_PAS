package kr.ac.kopo.project_pas.character;

public class SkillLoadout {
    // TODO: 구현 예정
}
