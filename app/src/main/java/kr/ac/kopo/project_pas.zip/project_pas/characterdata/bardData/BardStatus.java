package kr.ac.kopo.project_pas.characterdata.bardData;

public class BardStatus {
    // TODO: {class_name} 구현 예정
}
