package kr.ac.kopo.project_pas.ui;

public class EventActivity {
    // TODO: 구현 예정
}
