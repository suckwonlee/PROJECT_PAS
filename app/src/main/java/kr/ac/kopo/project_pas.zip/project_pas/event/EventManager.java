package kr.ac.kopo.project_pas.event;

public class EventManager {
    // TODO: 구현 예정
}
