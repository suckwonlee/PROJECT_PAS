package kr.ac.kopo.project_pas.enemydata;

public class EnemyFactory {
    // TODO: 구현 예정
}
