package kr.ac.kopo.project_pas.chapterflow;

public class ChapterData {
    // TODO: 구현 예정
}
