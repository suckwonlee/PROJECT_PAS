package kr.ac.kopo.project_pas.battle;

public class TurnEffectProcessor {
    // TODO: 구현 예정
}
