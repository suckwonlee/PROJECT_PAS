package kr.ac.kopo.project_pas.chapterflow;

public class SlotRouter {
    // TODO: 구현 예정
}
