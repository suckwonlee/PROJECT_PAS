package kr.ac.kopo.project_pas.characterdata.clericData;

public class ClericItemSet {
    // TODO: {class_name} 구현 예정
}
