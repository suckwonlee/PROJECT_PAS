package kr.ac.kopo.project_pas.publicdata;

public class PassiveSkill {
    // TODO: 구현 예정
}
