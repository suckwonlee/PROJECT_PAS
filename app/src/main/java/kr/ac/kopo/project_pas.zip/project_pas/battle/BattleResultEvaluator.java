package kr.ac.kopo.project_pas.battle;

public class BattleResultEvaluator {
    // TODO: 구현 예정
}
