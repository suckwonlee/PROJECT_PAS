package kr.ac.kopo.project_pas.characterdata.bardData;

public class BardSkillSet {
    // TODO: {class_name} 구현 예정
}
