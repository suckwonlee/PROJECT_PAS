package kr.ac.kopo.project_pas.characterdata.hunterData;

public class HunterItemSet {
    // TODO: {class_name} 구현 예정
}
