package kr.ac.kopo.project_pas.save;

public class SaveManager {
    // TODO: 구현 예정
}
