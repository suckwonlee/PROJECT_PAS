package kr.ac.kopo.project_pas.publicdata;

public class PublicSkill {
    // TODO: 구현 예정
}
