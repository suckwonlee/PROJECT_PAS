package kr.ac.kopo.project_pas.characterdata.otherworlderData;

public class OtherworlderData {
    // TODO: {class_name} 구현 예정
}
