package kr.ac.kopo.project_pas.ui;

public class ShopActivity {
    // TODO: 구현 예정
}
