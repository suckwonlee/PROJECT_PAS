package kr.ac.kopo.project_pas.character;

public class PlayerCharacter {
    // TODO: 구현 예정
}
