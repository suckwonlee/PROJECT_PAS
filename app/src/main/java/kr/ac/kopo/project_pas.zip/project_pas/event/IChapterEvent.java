package kr.ac.kopo.project_pas.event;

import kr.ac.kopo.project_pas.playerdata.PlayerState;

public interface IChapterEvent {
    String getType(); // "battle", "choice", "reward" 등
    void startEvent(PlayerState player);
    boolean isComplete();
    IChapterEvent getNextEvent();
}
