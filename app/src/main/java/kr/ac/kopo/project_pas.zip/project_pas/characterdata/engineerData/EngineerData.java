package kr.ac.kopo.project_pas.characterdata.engineerData;

public class EngineerData {
    // TODO: {class_name} 구현 예정
}
