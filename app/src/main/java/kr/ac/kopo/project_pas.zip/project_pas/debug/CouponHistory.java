package kr.ac.kopo.project_pas.debug;

public class CouponHistory {
    // TODO: 구현 예정
}
