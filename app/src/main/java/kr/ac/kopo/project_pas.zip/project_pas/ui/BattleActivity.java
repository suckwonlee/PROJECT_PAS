package kr.ac.kopo.project_pas.ui;

public class BattleActivity {
    // TODO: 구현 예정
}
