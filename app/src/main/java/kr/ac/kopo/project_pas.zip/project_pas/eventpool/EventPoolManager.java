package kr.ac.kopo.project_pas.eventpool;

public class EventPoolManager {
    // TODO: 구현 예정
}
