package kr.ac.kopo.project_pas.battle;

public class CombatLogger {
    // TODO: 구현 예정
}
