package kr.ac.kopo.project_pas.characterdata.herodata;

public class HeroCandidateStatus {
    // TODO: 구현 예정
}
