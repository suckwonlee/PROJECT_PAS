package kr.ac.kopo.project_pas.ui;

import android.app.Activity;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import kr.ac.kopo.project_pas.R;

public class ContinentSelectionActivity extends AppCompatActivity
 {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_continent_selection);
        // TODO: 좌우 화살표 클릭 처리, 대륙 설명 변경, 다음 버튼 처리
    }
}
