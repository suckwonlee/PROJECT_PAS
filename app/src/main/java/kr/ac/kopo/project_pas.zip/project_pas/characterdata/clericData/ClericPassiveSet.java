package kr.ac.kopo.project_pas.characterdata.clericData;

public class ClericPassiveSet {
    // TODO: {class_name} 구현 예정
}
